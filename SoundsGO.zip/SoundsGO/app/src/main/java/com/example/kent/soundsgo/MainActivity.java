package com.example.kent.soundsgo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Geocoder;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.location.Address;
import android.location.Location;


import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, LocationListener {
    private LocationManager lManager;
    private String source_choice = "";
    private Location localisation;
    private Button play, stop, begin;
    private MediaRecorder rec;
    private String File;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        play = (Button) findViewById(R.id.play);
        stop = (Button) findViewById(R.id.stop);
        begin = (Button) findViewById(R.id.record);
        stop.setEnabled(false);
        play.setEnabled(false);
        File = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recording.3gp";
        rec = new MediaRecorder();
        rec.setAudioSource(MediaRecorder.AudioSource.MIC);  //to use the mic
        rec.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);// to record in 3gp
        rec.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        rec.setOutputFile(File);
        //rec.setOutputFile(" ");
        //On spécifie que l'on va avoir besoin de gérer l'affichage du cercle de chargement
       // requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);

        //On récupère le service de localisation
        lManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        //Initialisation de l'écran
        initialize_Screen();

        //On affecte un écouteur d'évènement aux boutons
        findViewById(R.id.source_choice).setOnClickListener(this);
        findViewById(R.id.get_pos).setOnClickListener(this);
        findViewById(R.id.show_address).setOnClickListener(this);

        begin.setOnClickListener(new View.OnClickListener() { //to start to record
            @Override
            public void onClick(View v) {
                try {
                    rec.prepare();
                    rec.start();
                } catch (IllegalStateException ise) {
                    // make something ...
                } catch (IOException ioe) {
                    // make something
                }
                begin.setEnabled(false);
                stop.setEnabled(true);
                Toast.makeText(getApplicationContext(), "Recording laucnhed", Toast.LENGTH_LONG).show();
            }
        });

        stop.setOnClickListener(new View.OnClickListener() { //to stop and save the audio
            @Override
            public void onClick(View v) {
                rec.stop();
                rec.release();
                rec = null;
                begin.setEnabled(true);
                stop.setEnabled(false);
                play.setEnabled(true);
                Toast.makeText(getApplicationContext(), "Audio Recorded successfully", Toast.LENGTH_LONG).show();
            }
        });

        play.setOnClickListener(new View.OnClickListener() { // to listen the sound
            @Override
            public void onClick(View v) {
                MediaPlayer mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(File);
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                    Toast.makeText(getApplicationContext(), "Listening Audio", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    // make something
                }
            }
        });
    }


    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.source_choice:
                sourceChoice();
                break;
            case R.id.get_pos:
                getPos();
                break;
            case R.id.show_address:
                showAddress();
                break;
            default:
                break;
        }
    }

    //To re-initialize the screen
    private void initialize_Screen() {
        ((TextView) findViewById(R.id.latitude)).setText("0.0");
        ((TextView) findViewById(R.id.longitude)).setText("0.0");
        ((TextView) findViewById(R.id.altitude)).setText("0.0");
        ((TextView) findViewById(R.id.adresse)).setText("");

        findViewById(R.id.get_pos).setEnabled(false);
        findViewById(R.id.show_address).setEnabled(false);
    }

    private void sourceChoice() {
        initialize_Screen();

        //To see which providers are useable
        List<String> providers = lManager.getProviders(true);
        final String[] sources = new String[providers.size()];
        int i = 0;
        //to store the source names in a string table
        for (String provider : providers)
            sources[i++] = provider;

        //to show the user the different providers that he can use
        new AlertDialog.Builder(MainActivity.this)
                .setItems(sources, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        findViewById(R.id.get_pos).setEnabled(true);
                        //we store the choice of the user
                        source_choice = sources[which];
                        //and then we add it to the title bar
                        setTitle(String.format("%s - %s", getString(R.string.app_name),
                                source_choice));
                    }
                })
                .create().show();
    }

    private void getPos() {
        //we show the loading bar
        setProgressBarIndeterminateVisibility(true);

        //we show the changes of the position which is given by the provider every minutes
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        lManager.requestLocationUpdates(source_choice, 60000, 0, this);
    }

    private void showPos() {
        //we show the informations of the user position
        ((TextView)findViewById(R.id.latitude)).setText(String.valueOf(localisation.getLatitude()));
        ((TextView)findViewById(R.id.longitude)).setText(String.valueOf(localisation.getLongitude()));
        ((TextView)findViewById(R.id.altitude)).setText(String.valueOf(localisation.getAltitude()));
    }

    private void showAddress() {
        setProgressBarIndeterminateVisibility(true);


        //The geocoder can retrieve or search addresses with a keyword or position
        Geocoder geo = new Geocoder(MainActivity.this);
        try {
            //Here we show the first address we found thanks to the position we retrieved
            List
                    <Address> adresses = geo.getFromLocation(localisation.getLatitude(),
                    localisation.getLongitude(),1);

            if(adresses != null && adresses.size() == 1){
                Address adresse = adresses.get(0);
                //if the geocoder has found an address, we show it
                ((TextView)findViewById(R.id.adresse)).setText(String.format("%s, %s %s",
                        adresse.getAddressLine(0),
                        adresse.getPostalCode(),
                        adresse.getLocality()));
            }
            else {
                //if not we show errors
                ((TextView)findViewById(R.id.adresse)).setText("L'adresse n'a pu être déterminée");
            }
        } catch (IOException e) {
            e.printStackTrace();
            ((TextView)findViewById(R.id.adresse)).setText("L'adresse n'a pu être déterminée");
        }
        //we stop the progress bar
        setProgressBarIndeterminateVisibility(false);
    }

    public void onLocationChanged(Location location) {
        //when the position change...
        Log.i("SOUNDSGO", "The position has changed.");
        //we stop the bar
        setProgressBarIndeterminateVisibility(false);
        // we enable the button to show the address
        findViewById(R.id.show_address).setEnabled(true);
        //we save the position
        this.localisation = location;
        //we show it
        showPos();
        //and we stop the updates
        lManager.removeUpdates(this);
    }

    public void onProviderDisabled(String provider) {
        //when the source is disabled
        Log.i("SOUNDSGO", "The source is disabled");
        //we show it to the user with a toast
        Toast.makeText(MainActivity.this,
                String.format("the source \"%s\" has been enabled", provider),
                Toast.LENGTH_SHORT).show();
        //and we stop the updates
        lManager.removeUpdates(this);
        //and the bar
        setProgressBarIndeterminateVisibility(false);
    }

    public void onProviderEnabled(String provider) {
        Log.i("SOUNDSGO", "The source is enabled.");
    }
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Log.i("SOUNDSGO", "The provider status has changed.");
    }


};